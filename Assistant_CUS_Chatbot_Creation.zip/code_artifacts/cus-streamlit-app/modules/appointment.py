
"""
Module de gestion des rendez-vous avec intégration Google Calendar
"""

import streamlit as st
from datetime import datetime, timedelta
import json
from modules.google_services import create_calendar_event, send_appointment_notification
from config import APPOINTMENT_TYPES

def display_appointment_form():
    """Affiche le formulaire de prise de rendez-vous"""
    st.markdown("## 📅 Prendre Rendez-vous")
    st.markdown("Planifiez un rendez-vous avec l'équipe du CUS. Nous vous contacterons pour confirmer.")
    
    st.markdown("---")
    
    # Formulaire
    with st.form("appointment_form", clear_on_submit=True):
        st.markdown("### 📝 Vos informations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input(
                "Nom complet *",
                placeholder="Ex: Jean Dupont"
            )
            email = st.text_input(
                "Email *",
                placeholder="Ex: jean.dupont@exemple.com"
            )
        
        with col2:
            phone = st.text_input(
                "Téléphone",
                placeholder="Ex: +212 6XX XXX XXX"
            )
            organization = st.text_input(
                "Organisation",
                placeholder="Ex: Université / Entreprise"
            )
        
        st.markdown("### 🗓️ Détails du rendez-vous")
        
        col1, col2 = st.columns(2)
        
        with col1:
            appointment_date = st.date_input(
                "Date souhaitée *",
                min_value=datetime.now().date(),
                value=datetime.now().date() + timedelta(days=1)
            )
        
        with col2:
            appointment_time = st.time_input(
                "Heure souhaitée *",
                value=datetime.strptime("09:00", "%H:%M").time()
            )
        
        appointment_type = st.selectbox(
            "Type de rendez-vous *",
            APPOINTMENT_TYPES
        )
        
        duration = st.selectbox(
            "Durée estimée *",
            ["30 minutes", "1 heure", "1h30", "2 heures"],
            index=1
        )
        
        description = st.text_area(
            "Description / Objet du rendez-vous *",
            placeholder="Décrivez brièvement l'objet de votre rendez-vous...",
            height=150
        )
        
        st.markdown("---")
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            submit_button = st.form_submit_button(
                "📅 Confirmer le rendez-vous",
                use_container_width=True
            )
    
    # Traitement du formulaire
    if submit_button:
        # Validation
        if not name or not email or not description:
            st.error("❌ Veuillez remplir tous les champs obligatoires (marqués par *)")
            return
        
        # Validation email
        if "@" not in email or "." not in email:
            st.error("❌ Veuillez entrer une adresse email valide")
            return
        
        # Créer l'événement
        with st.spinner("⏳ Création du rendez-vous..."):
            # Combiner date et heure
            appointment_datetime = datetime.combine(appointment_date, appointment_time)
            
            # Calculer la durée
            duration_map = {
                "30 minutes": 30,
                "1 heure": 60,
                "1h30": 90,
                "2 heures": 120
            }
            duration_minutes = duration_map[duration]
            end_datetime = appointment_datetime + timedelta(minutes=duration_minutes)
            
            # Préparer les données
            appointment_data = {
                "name": name,
                "email": email,
                "phone": phone,
                "organization": organization,
                "datetime": appointment_datetime.strftime("%d/%m/%Y à %H:%M"),
                "type": appointment_type,
                "duration": duration,
                "description": description
            }
            
            # Créer l'événement dans Google Calendar
            event_summary = f"Rendez-vous CUS: {name} - {appointment_type}"
            event_description = f"""
            Type: {appointment_type}
            Durée: {duration}
            Organisation: {organization or 'Non spécifié'}
            Téléphone: {phone or 'Non spécifié'}
            
            Description:
            {description}
            
            ---
            Demande soumise via le portail CUS
            """
            
            # Note: En production, utiliser l'API Google Calendar réelle
            calendar_result = create_calendar_event(
                summary=event_summary,
                description=event_description,
                start_time=appointment_datetime,
                end_time=end_datetime,
                attendee_email=email
            )
            
            if calendar_result["success"]:
                # Envoyer la notification email
                notification_result = send_appointment_notification(appointment_data)
                
                if notification_result["success"]:
                    st.success("✅ Votre demande de rendez-vous a été envoyée avec succès!")
                    st.balloons()
                    
                    # Afficher un résumé
                    st.markdown("---")
                    st.markdown("### 📋 Récapitulatif de votre rendez-vous")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.info(f"""
                        **👤 Contact:**
                        - Nom: {name}
                        - Email: {email}
                        - Tél: {phone or 'Non spécifié'}
                        """)
                    
                    with col2:
                        st.info(f"""
                        **🗓️ Rendez-vous:**
                        - Date: {appointment_date.strftime('%d/%m/%Y')}
                        - Heure: {appointment_time.strftime('%H:%M')}
                        - Durée: {duration}
                        - Type: {appointment_type}
                        """)
                    
                    st.markdown("""
                    ### ℹ️ Prochaines étapes:
                    
                    1. ✅ Votre demande a été reçue
                    2. 📧 Vous recevrez un email de confirmation dans les 24h
                    3. 📞 Notre équipe vous contactera pour confirmer le créneau
                    4. 🗓️ Le rendez-vous sera ajouté à votre calendrier
                    
                    **En cas d'urgence, contactez-nous directement:**
                    📧 seyidebnou@gmail.com
                    """)
                else:
                    st.warning("⚠️ Rendez-vous créé mais erreur d'envoi de notification. Nous vous contacterons bientôt.")
            else:
                st.error(f"❌ Erreur lors de la création du rendez-vous: {calendar_result['message']}")
    
    # Informations complémentaires
    st.markdown("---")
    st.markdown("### ℹ️ Informations pratiques")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **📍 Adresse:**
        Centre for Urban Systems  
        UM6P - Ben Guerir  
        Maroc
        """)
    
    with col2:
        st.markdown("""
        **⏰ Horaires:**
        Lundi - Vendredi  
        9h00 - 17h00  
        (GMT+1)
        """)
    
    with col3:
        st.markdown("""
        **📞 Contact:**
        📧 seyidebnou@gmail.com  
        🌐 [cus.um6p.ma](https://cus.um6p.ma)
        """)
