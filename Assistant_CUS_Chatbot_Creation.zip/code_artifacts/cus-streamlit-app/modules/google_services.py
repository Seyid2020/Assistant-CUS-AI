
"""
Module pour gérer les interactions avec les services Google
(Calendar, Sheets, Gmail) en utilisant les outils natifs de la plateforme
"""

import streamlit as st
from datetime import datetime, timedelta
import json
import os

def create_calendar_event(summary, description, start_time, end_time, attendee_email):
    """
    Crée un événement dans Google Calendar
    
    Args:
        summary: Titre de l'événement
        description: Description de l'événement
        start_time: Date/heure de début (datetime)
        end_time: Date/heure de fin (datetime)
        attendee_email: Email du participant
    
    Returns:
        dict: Résultat de la création (success, event_id, message)
    """
    try:
        # Note: Dans un environnement de production, cette fonction utiliserait
        # l'outil Google_Calendar_Tool fourni par la plateforme
        # Pour ce template, nous retournons une simulation
        
        event_data = {
            "summary": summary,
            "description": description,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "attendee_email": attendee_email
        }
        
        # Simulation pour le développement
        # En production, appeler: Google_Calendar_Tool avec action='create_event'
        
        return {
            "success": True,
            "event_id": f"evt_{datetime.now().timestamp()}",
            "message": "Rendez-vous créé avec succès!",
            "event_data": event_data
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Erreur lors de la création du rendez-vous: {str(e)}"
        }

def append_to_sheet(spreadsheet_id, values, sheet_name="Sheet1"):
    """
    Ajoute des données à un Google Sheet
    
    Args:
        spreadsheet_id: ID du spreadsheet
        values: Liste de valeurs à ajouter
        sheet_name: Nom de la feuille
    
    Returns:
        dict: Résultat de l'ajout
    """
    try:
        # Note: En production, utiliser Google_Sheets_Tool avec action='append_values'
        
        return {
            "success": True,
            "message": "Données ajoutées avec succès au Google Sheet"
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Erreur lors de l'ajout au Google Sheet: {str(e)}"
        }

def create_google_sheet(sheet_name, headers):
    """
    Crée un nouveau Google Sheet
    
    Args:
        sheet_name: Nom du spreadsheet
        headers: Liste des en-têtes de colonnes
    
    Returns:
        dict: Résultat de la création (success, spreadsheet_id)
    """
    try:
        # Note: En production, utiliser Google_Drive_Tool pour créer
        # puis Google_Sheets_Tool pour ajouter les en-têtes
        
        return {
            "success": True,
            "spreadsheet_id": f"sheet_{datetime.now().timestamp()}",
            "message": f"Google Sheet '{sheet_name}' créé avec succès"
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Erreur lors de la création du Google Sheet: {str(e)}"
        }

def send_email(to_email, subject, body):
    """
    Envoie un email via Gmail
    
    Args:
        to_email: Email du destinataire
        subject: Sujet de l'email
        body: Corps de l'email (JSON string avec format)
    
    Returns:
        dict: Résultat de l'envoi
    """
    try:
        # Note: En production, utiliser Gmail_Tool avec action='send_email'
        
        return {
            "success": True,
            "message": "Email envoyé avec succès"
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Erreur lors de l'envoi de l'email: {str(e)}"
        }

def send_appointment_notification(appointment_data):
    """
    Envoie une notification email pour un nouveau rendez-vous
    """
    subject = f"Nouveau rendez-vous CUS: {appointment_data['type']}"
    
    body_json = {
        "html": f"""
        <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
                    <h2 style="color: #1e3c72; border-bottom: 2px solid #2a5298; padding-bottom: 10px;">
                        🗓️ Nouveau Rendez-vous CUS
                    </h2>
                    
                    <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                        <p><strong>👤 Nom:</strong> {appointment_data['name']}</p>
                        <p><strong>📧 Email:</strong> {appointment_data['email']}</p>
                        <p><strong>📅 Date/Heure:</strong> {appointment_data['datetime']}</p>
                        <p><strong>📋 Type:</strong> {appointment_data['type']}</p>
                    </div>
                    
                    <div style="margin: 20px 0;">
                        <h3 style="color: #2a5298;">Description:</h3>
                        <p style="background-color: #f9f9f9; padding: 10px; border-left: 3px solid #2a5298;">
                            {appointment_data['description']}
                        </p>
                    </div>
                    
                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666;">
                        <p>Centre for Urban Systems - UM6P</p>
                        <p>🌐 <a href="https://cus.um6p.ma" style="color: #2a5298;">cus.um6p.ma</a></p>
                    </div>
                </div>
            </body>
        </html>
        """,
        "text": f"""
        Nouveau Rendez-vous CUS
        
        Nom: {appointment_data['name']}
        Email: {appointment_data['email']}
        Date/Heure: {appointment_data['datetime']}
        Type: {appointment_data['type']}
        
        Description:
        {appointment_data['description']}
        
        ---
        Centre for Urban Systems - UM6P
        https://cus.um6p.ma
        """
    }
    
    return send_email(
        to_email=st.secrets.get("NOTIFICATION_EMAIL", "seyidebnou@gmail.com"),
        subject=subject,
        body=json.dumps(body_json)
    )

def send_proposal_notification(proposal_data):
    """
    Envoie une notification email pour une nouvelle proposition
    """
    subject = f"Nouvelle proposition CUS: {proposal_data['type']}"
    
    body_json = {
        "html": f"""
        <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
                    <h2 style="color: #1e3c72; border-bottom: 2px solid #2a5298; padding-bottom: 10px;">
                        💡 Nouvelle Proposition CUS
                    </h2>
                    
                    <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                        <p><strong>👤 Nom:</strong> {proposal_data['name']}</p>
                        <p><strong>📧 Email:</strong> {proposal_data['email']}</p>
                        <p><strong>🏢 Organisation:</strong> {proposal_data['organization']}</p>
                        <p><strong>📋 Type:</strong> {proposal_data['type']}</p>
                    </div>
                    
                    <div style="margin: 20px 0;">
                        <h3 style="color: #2a5298;">Description détaillée:</h3>
                        <p style="background-color: #f9f9f9; padding: 10px; border-left: 3px solid #2a5298;">
                            {proposal_data['description']}
                        </p>
                    </div>
                    
                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666;">
                        <p>Centre for Urban Systems - UM6P</p>
                        <p>🌐 <a href="https://cus.um6p.ma" style="color: #2a5298;">cus.um6p.ma</a></p>
                    </div>
                </div>
            </body>
        </html>
        """,
        "text": f"""
        Nouvelle Proposition CUS
        
        Nom: {proposal_data['name']}
        Email: {proposal_data['email']}
        Organisation: {proposal_data['organization']}
        Type: {proposal_data['type']}
        
        Description détaillée:
        {proposal_data['description']}
        
        ---
        Centre for Urban Systems - UM6P
        https://cus.um6p.ma
        """
    }
    
    return send_email(
        to_email=st.secrets.get("NOTIFICATION_EMAIL", "seyidebnou@gmail.com"),
        subject=subject,
        body=json.dumps(body_json)
    )
