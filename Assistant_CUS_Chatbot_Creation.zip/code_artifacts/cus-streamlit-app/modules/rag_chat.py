
"""
Module de chat intelligent avec RAG (Retrieval Augmented Generation)
pour répondre aux questions sur le CUS
"""

import streamlit as st
import numpy as np
from typing import List, Tuple
import os
import re

# Simple embedding basé sur TF-IDF pour éviter les dépendances lourdes
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class SimpleRAGSystem:
    """Système RAG simple utilisant TF-IDF pour la recherche de similarité"""
    
    def __init__(self, knowledge_file: str):
        self.knowledge_file = knowledge_file
        self.chunks = []
        self.vectorizer = None
        self.tfidf_matrix = None
        self.load_knowledge()
        
    def load_knowledge(self):
        """Charge et prépare la base de connaissances"""
        if not os.path.exists(self.knowledge_file):
            st.error(f"❌ Fichier de connaissances introuvable: {self.knowledge_file}")
            return
        
        with open(self.knowledge_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Découpage en chunks
        self.chunks = self._create_chunks(content, chunk_size=500, overlap=50)
        
        # Création de la matrice TF-IDF
        if self.chunks:
            self.vectorizer = TfidfVectorizer(
                max_features=1000,
                ngram_range=(1, 2),
                stop_words=None  # Garder les stop words pour le français
            )
            self.tfidf_matrix = self.vectorizer.fit_transform(self.chunks)
    
    def _create_chunks(self, text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """Découpe le texte en chunks avec chevauchement"""
        # Nettoyer le texte
        text = re.sub(r'\s+', ' ', text)
        
        # Diviser en phrases (approximatif)
        sentences = re.split(r'[.!?]+', text)
        
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            if len(current_chunk) + len(sentence) < chunk_size:
                current_chunk += sentence + ". "
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence + ". "
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def search(self, query: str, top_k: int = 3) -> List[Tuple[str, float]]:
        """Recherche les chunks les plus pertinents"""
        if not self.chunks or self.vectorizer is None:
            return []
        
        # Vectoriser la requête
        query_vec = self.vectorizer.transform([query])
        
        # Calculer la similarité
        similarities = cosine_similarity(query_vec, self.tfidf_matrix)[0]
        
        # Récupérer les top_k résultats
        top_indices = np.argsort(similarities)[::-1][:top_k]
        
        results = [
            (self.chunks[idx], float(similarities[idx]))
            for idx in top_indices
            if similarities[idx] > 0.01  # Seuil minimal
        ]
        
        return results
    
    def generate_answer(self, query: str, context_chunks: List[Tuple[str, float]]) -> str:
        """Génère une réponse basée sur le contexte"""
        if not context_chunks:
            return """
            Je n'ai pas trouvé d'information spécifique dans ma base de connaissances pour répondre à cette question. 
            
            Cependant, je peux vous diriger vers notre site web (https://cus.um6p.ma) ou vous pouvez prendre rendez-vous 
            avec notre équipe via l'onglet "Prendre Rendez-vous".
            """
        
        # Construire le contexte
        context = "\n\n".join([chunk for chunk, _ in context_chunks])
        
        # Réponse simple basée sur le contexte
        response = f"""
Basé sur les informations du Centre for Urban Systems (CUS), voici ma réponse :

{context}

---

**Sources utilisées:** Documentation officielle du CUS

💡 Pour plus d'informations ou pour discuter d'une collaboration, n'hésitez pas à prendre rendez-vous avec notre équipe !
        """
        
        return response.strip()

def initialize_rag():
    """Initialise le système RAG"""
    if 'rag_system' not in st.session_state:
        knowledge_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'cus_knowledge.txt')
        st.session_state.rag_system = SimpleRAGSystem(knowledge_file)

def display_chat_interface():
    """Affiche l'interface de chat"""
    st.markdown("## 🤖 Chat Intelligent CUS")
    st.markdown("Posez vos questions sur le Centre for Urban Systems, ses recherches, ses équipes et ses projets.")
    
    # Initialiser le système RAG
    initialize_rag()
    
    # Initialiser l'historique de chat
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    # Zone de chat
    st.markdown("---")
    
    # Afficher l'historique
    for i, message in enumerate(st.session_state.chat_history):
        if message["role"] == "user":
            st.markdown(f"""
                <div class="chat-message user-message">
                    <strong>👤 Vous:</strong><br>
                    {message["content"]}
                </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
                <div class="chat-message assistant-message">
                    <strong>🤖 Assistant CUS:</strong><br>
                    {message["content"].replace(chr(10), '<br>')}
                </div>
            """, unsafe_allow_html=True)
    
    # Questions suggérées
    if not st.session_state.chat_history:
        st.markdown("### 💡 Questions suggérées:")
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🎯 Quelle est la mission du CUS ?"):
                handle_query("Quelle est la mission du CUS ?")
            if st.button("👥 Qui sont les membres de l'équipe ?"):
                handle_query("Qui sont les membres de l'équipe ?")
        
        with col2:
            if st.button("🔬 Quelles sont les thématiques de recherche ?"):
                handle_query("Quelles sont les thématiques de recherche ?")
            if st.button("🎓 Quelle est la vision du CUS ?"):
                handle_query("Quelle est la vision du CUS ?")
    
    # Zone de saisie
    st.markdown("---")
    col1, col2 = st.columns([5, 1])
    
    with col1:
        user_query = st.text_input(
            "Votre question:",
            key="user_input",
            placeholder="Posez votre question ici..."
        )
    
    with col2:
        send_button = st.button("Envoyer 📤", use_container_width=True)
    
    # Traiter la question
    if send_button and user_query:
        handle_query(user_query)
        st.rerun()
    
    # Bouton pour effacer l'historique
    if st.session_state.chat_history:
        st.markdown("---")
        if st.button("🗑️ Effacer l'historique"):
            st.session_state.chat_history = []
            st.rerun()

def handle_query(query: str):
    """Traite une requête utilisateur"""
    # Ajouter la question à l'historique
    st.session_state.chat_history.append({
        "role": "user",
        "content": query
    })
    
    # Rechercher dans la base de connaissances
    rag_system = st.session_state.rag_system
    context_chunks = rag_system.search(query, top_k=3)
    
    # Générer la réponse
    answer = rag_system.generate_answer(query, context_chunks)
    
    # Ajouter la réponse à l'historique
    st.session_state.chat_history.append({
        "role": "assistant",
        "content": answer
    })
