
"""
Module de gestion des propositions de collaboration avec intégration Google Sheets
"""

import streamlit as st
from datetime import datetime
from modules.google_services import append_to_sheet, create_google_sheet, send_proposal_notification
from config import PROPOSAL_TYPES, PROPOSALS_SHEET_NAME, PROPOSALS_SHEET_HEADERS

def display_proposal_form():
    """Affiche le formulaire de soumission de propositions"""
    st.markdown("## 💡 Soumettre une Proposition")
    st.markdown("Proposez une collaboration, un partenariat ou un projet avec le Centre for Urban Systems.")
    
    st.markdown("---")
    
    # Formulaire
    with st.form("proposal_form", clear_on_submit=True):
        st.markdown("### 📝 Vos informations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input(
                "Nom complet *",
                placeholder="Ex: Marie Martin"
            )
            email = st.text_input(
                "Email *",
                placeholder="Ex: marie.martin@exemple.com"
            )
        
        with col2:
            organization = st.text_input(
                "Organisation *",
                placeholder="Ex: Université, Entreprise, ONG..."
            )
            position = st.text_input(
                "Poste / Fonction",
                placeholder="Ex: Chercheur, Directeur, Étudiant..."
            )
        
        st.markdown("### 💼 Détails de la proposition")
        
        proposal_type = st.selectbox(
            "Type de proposition *",
            PROPOSAL_TYPES
        )
        
        title = st.text_input(
            "Titre de la proposition *",
            placeholder="Ex: Collaboration sur la mobilité urbaine durable"
        )
        
        # Domaines d'intérêt
        st.markdown("**Domaines d'intérêt (sélectionnez tous ceux qui s'appliquent):**")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            smart_cities = st.checkbox("🏙️ Smart Cities")
            mobility = st.checkbox("🚗 Mobilité")
            energy = st.checkbox("⚡ Énergie")
        
        with col2:
            health = st.checkbox("🏥 Santé urbaine")
            agriculture = st.checkbox("🌾 Agriculture urbaine")
            infrastructure = st.checkbox("🏗️ Infrastructure")
        
        with col3:
            digital = st.checkbox("💻 Développement digital")
            environment = st.checkbox("🌱 Environnement")
            data_science = st.checkbox("📊 Data Science")
        
        description = st.text_area(
            "Description détaillée de la proposition *",
            placeholder="""Décrivez votre proposition en détail:
- Contexte et objectifs
- Méthodologie envisagée
- Résultats attendus
- Ressources nécessaires
- Durée du projet
- Toute autre information pertinente""",
            height=250
        )
        
        # Budget et timeline
        col1, col2 = st.columns(2)
        
        with col1:
            budget_range = st.selectbox(
                "Budget estimé (optionnel)",
                ["Non spécifié", "< 50k MAD", "50k-100k MAD", "100k-500k MAD", "> 500k MAD"]
            )
        
        with col2:
            timeline = st.selectbox(
                "Durée estimée (optionnel)",
                ["Non spécifié", "< 3 mois", "3-6 mois", "6-12 mois", "1-2 ans", "> 2 ans"]
            )
        
        # Documents joints
        uploaded_file = st.file_uploader(
            "Joindre un document (optionnel)",
            type=['pdf', 'doc', 'docx', 'ppt', 'pptx'],
            help="Vous pouvez joindre un document de présentation, une proposition détaillée, etc."
        )
        
        st.markdown("---")
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            submit_button = st.form_submit_button(
                "💡 Soumettre la proposition",
                use_container_width=True
            )
    
    # Traitement du formulaire
    if submit_button:
        # Validation
        if not name or not email or not organization or not title or not description:
            st.error("❌ Veuillez remplir tous les champs obligatoires (marqués par *)")
            return
        
        # Validation email
        if "@" not in email or "." not in email:
            st.error("❌ Veuillez entrer une adresse email valide")
            return
        
        # Construire la liste des domaines d'intérêt
        interests = []
        if smart_cities: interests.append("Smart Cities")
        if mobility: interests.append("Mobilité")
        if energy: interests.append("Énergie")
        if health: interests.append("Santé urbaine")
        if agriculture: interests.append("Agriculture urbaine")
        if infrastructure: interests.append("Infrastructure")
        if digital: interests.append("Développement digital")
        if environment: interests.append("Environnement")
        if data_science: interests.append("Data Science")
        
        interests_str = ", ".join(interests) if interests else "Non spécifié"
        
        with st.spinner("⏳ Soumission de votre proposition..."):
            # Préparer les données
            submission_date = datetime.now().strftime("%d/%m/%Y %H:%M")
            
            proposal_data = {
                "date": submission_date,
                "name": name,
                "email": email,
                "organization": organization,
                "position": position or "Non spécifié",
                "type": proposal_type,
                "title": title,
                "interests": interests_str,
                "description": description,
                "budget": budget_range,
                "timeline": timeline,
                "has_attachment": "Oui" if uploaded_file else "Non"
            }
            
            # Données pour Google Sheets
            sheet_row = [
                submission_date,
                name,
                email,
                organization,
                proposal_type,
                title,
                interests_str,
                description,
                budget_range,
                timeline,
                "En attente"  # Statut
            ]
            
            # Note: En production, vérifier si le sheet existe et le créer si nécessaire
            # puis ajouter les données
            
            # Simulation pour le développement
            sheet_result = {"success": True}
            
            if sheet_result["success"]:
                # Envoyer la notification email
                email_data = {
                    "name": name,
                    "email": email,
                    "organization": organization,
                    "type": proposal_type,
                    "description": f"""
**Titre:** {title}

**Position:** {position or 'Non spécifié'}

**Domaines d'intérêt:** {interests_str}

**Description:**
{description}

**Budget estimé:** {budget_range}
**Durée estimée:** {timeline}
**Document joint:** {'Oui' if uploaded_file else 'Non'}
                    """
                }
                
                notification_result = send_proposal_notification(email_data)
                
                if notification_result["success"]:
                    st.success("✅ Votre proposition a été soumise avec succès!")
                    st.balloons()
                    
                    # Afficher un résumé
                    st.markdown("---")
                    st.markdown("### 📋 Récapitulatif de votre proposition")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.info(f"""
                        **👤 Contact:**
                        - Nom: {name}
                        - Email: {email}
                        - Organisation: {organization}
                        - Poste: {position or 'Non spécifié'}
                        """)
                    
                    with col2:
                        st.info(f"""
                        **💼 Proposition:**
                        - Type: {proposal_type}
                        - Titre: {title}
                        - Budget: {budget_range}
                        - Durée: {timeline}
                        """)
                    
                    if interests:
                        st.info(f"**🎯 Domaines d'intérêt:** {interests_str}")
                    
                    st.markdown("""
                    ### ℹ️ Prochaines étapes:
                    
                    1. ✅ Votre proposition a été reçue et enregistrée
                    2. 📧 Vous recevrez un accusé de réception par email
                    3. 🔍 Notre équipe examinera votre proposition
                    4. 📞 Nous vous recontacterons sous 5-7 jours ouvrables
                    5. 🤝 Si votre proposition est retenue, nous planifierons une réunion
                    
                    **Pour toute question:**
                    📧 seyidebnou@gmail.com
                    """)
                else:
                    st.warning("⚠️ Proposition enregistrée mais erreur d'envoi de notification. Nous vous contacterons bientôt.")
            else:
                st.error("❌ Erreur lors de l'enregistrement de la proposition. Veuillez réessayer.")
    
    # Informations sur les types de propositions
    st.markdown("---")
    st.markdown("### 📚 Types de propositions acceptées")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **🎓 Collaboration académique:**
        - Projets de recherche conjoints
        - Publications scientifiques
        - Échange de chercheurs
        - Co-supervision de thèses
        
        **🏭 Partenariat industriel:**
        - Projets R&D
        - Transfert de technologie
        - Consulting et expertise
        - Formation professionnelle
        
        **🔬 Projet de recherche:**
        - Recherche fondamentale
        - Recherche appliquée
        - Innovation technologique
        - Living Labs
        """)
    
    with col2:
        st.markdown("""
        **👨‍🎓 Stage/Formation:**
        - Stages de recherche
        - Stages d'ingénieur
        - Formation continue
        - Ateliers et séminaires
        
        **🧪 Living Lab:**
        - Projets de terrain
        - Expérimentation urbaine
        - Collecte de données
        - Test de solutions innovantes
        
        **💡 Autre:**
        - Toute autre forme de collaboration
        - Propositions innovantes
        - Partenariats créatifs
        """)
